// service-worker.js
chrome.commands.onCommand.addListener(async (command) => {
  const tabs = await chrome.tabs.query({});

  for (const tab of tabs) {
    if (!tab.id || !tab.url) continue;

    if (
      tab.url.startsWith("chrome://") ||
      tab.url.startsWith("chrome-extension://")
    ) continue;

    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: (cmd) => {
        window.postMessage(
          {
            __FIS_BRIDGE__: true,
            action: cmd
          },
          "*"
        );
      },
      args: [command]
    });
  }
});