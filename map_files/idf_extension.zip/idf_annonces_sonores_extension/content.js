// content.js
(() => {
  const VERSION = chrome?.runtime?.getManifest?.().version ?? null;

  window.addEventListener("message", (event) => {
    // Doit venir de la page elle-même
    if (event.source !== window) return;

    // Optionnel mais recommandé : ignore les messages cross-origin
    if (event.origin !== location.origin) return;

    const data = event.data;
    if (!data || data.type !== "MYEXT_PING" || !data.nonce) return;

    window.postMessage(
      {
        type: "MYEXT_PONG",
        nonce: data.nonce,
        version: VERSION,
        name: "FIS Bridge ETS2"
      },
      location.origin
    );
  });
})();